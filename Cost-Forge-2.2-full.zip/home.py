from __future__ import annotations
import streamlit as st

st.set_page_config(page_title="Cost Forge 2.2", layout="wide")
st.title("🛠️ Cost Forge 2.2 — First-Time-Right")
st.write("""
**Menu** links: Quick Cost (met beste supplier quotes), Data Quality, Scenario Planner,
Supplier Quotes, Offerte DOCX, Offerte PDF, Download Center.
""")
